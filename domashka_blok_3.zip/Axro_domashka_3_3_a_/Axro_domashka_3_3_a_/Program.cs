﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axro_domashka_3_3_a_
{
    public class Program
    {
       public static void Main(string[] args)
        {
            Console.WriteLine("Программа проверки простое ли число");
            Console.WriteLine("Введите число:");
             int testNumber = int.Parse(Console.ReadLine());
            int digit = 1;
            int dividersCount = 0;
            string dividers = "";

            do
            {
                if (testNumber % digit == 0)
                {
                    dividersCount++;
                    dividers = dividers + digit;
                }
                digit++;

            } while (digit < testNumber + 1);

            if (dividersCount < 3)
            {
                Console.WriteLine("Число: {0} - простое", testNumber);
            }
            else
            {
                Console.WriteLine("Число: {0} - не является простым", testNumber);
            }
        }
    }
}
