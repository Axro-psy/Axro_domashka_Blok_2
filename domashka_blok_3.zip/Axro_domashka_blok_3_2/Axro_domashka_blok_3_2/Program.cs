﻿
using System;
class Axro_domashka_blok_3_2
{
    static void Main()
    {
        Console.WriteLine("Введите количество карт у вас на руках");
        int cardCount = int.Parse(Console.ReadLine());
        Console.WriteLine("Введите номинал карты - число от 6 до 10, номинал для карт Валет - J, Дама - Q, Король - K, Туз - T");
        int cardSumm = 0;
        for (int i = 1; i <= cardCount; i++)
        {
            Console.WriteLine("Введите номинал карты {0}", i);
            string currentNominal = Console.ReadLine();
            switch (currentNominal)
            {
                case "6":
                    cardSumm = cardSumm + 6;
                    break;
                case "7":
                    cardSumm = cardSumm + 7;
                    break;
                case "8":
                    cardSumm = cardSumm + 8;
                    break;
                case "9":
                    cardSumm = cardSumm + 9;
                    break;
                case "10":
                    cardSumm = cardSumm + 10;
                    break;
                case "J":
                    cardSumm = cardSumm + 10;
                    break;
                // Здесь надо дописать другие варики
                default:
                    Console.WriteLine("Значение {0} не является номиналом карты", currentNominal);
                    i--;
                    break;
            }
        }
        Console.WriteLine("Общая сумма номиналов карт {0}", cardSumm);
     
    }
}