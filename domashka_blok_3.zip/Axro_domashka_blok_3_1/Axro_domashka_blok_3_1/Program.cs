﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Axro_domashka_3_1
{

    public class Program
    {
        public static void Main(string[] args)
        {
            int N = 65;
            Console.WriteLine("Введите число:");
            N = int.Parse(Console.ReadLine());


            if (N % 2 == 0)
            {
                Console.WriteLine("Поздравляем! Число четное!!!");
            }
            else if (N % 2 != 0)
            {
                Console.WriteLine("Сожалеем, но число нечетное!!!");
            }

            Console.ReadLine();

        }
    }
}
